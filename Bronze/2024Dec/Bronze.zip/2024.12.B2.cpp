#include <bits/stdc++.h>
using namespace std;

static int lineX[1000000]; 
static int lineY[1000000];
static int lineZ[1000000];

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	
	int N, Q;
	cin >> N >> Q;
	
	memset(lineX, 0, sizeof(int)*N*N);
	memset(lineY, 0, sizeof(int)*N*N);
	memset(lineZ, 0, sizeof(int)*N*N);
	
	long long countFullyCarved = 0;
	
	while(Q--){
		int x,y,z;
		cin >> x >> y >> z;
		
		{
			int idx = y*N + z;
			int oldVal = lineX[idx];
			int newVal = oldVal + 1;
			lineX[idx] = newVal;
			if(newVal == N) {
				countFullyCarved++;
			}
		}
		
		{
			int idx = x*N + z;
			int oldVal = lineY[idx];
			int newVal = oldVal + 1;
			lineY[idx] = newVal;
			if(newVal == N){
				countFullyCarved++;
			}
		}
		
		{
			int idx = x*N + y;
			int oldVal = lineZ[idx];
			int newVal = oldVal + 1;
			lineZ[idx] = newVal;
			if(newVal == N){
				countFullyCarved++;
			}
		}
		
		cout << countFullyCarved << "\n";
	}
	
	return 0;
}

