#include <bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	
	int T;
	cin >> T;
	vector<int> Ns(T);
	for(int &N: Ns){
		cin >> N;
	}
	
	vector<pair<int, int>> ranges;
	for(int P=2; P<=9; P++){
		string start_str = "";
		for(int i=0; i<P-1; i++) start_str += "4";
		start_str += "5";
		int start = stoi(start_str);
		
		string end_str = "4";
		for(int i=0; i<P-1; i++) end_str += "9";
		int end = stoi(end_str);
		
		ranges.emplace_back(make_pair(start, end));
	}
	for(auto &N: Ns){
		if(N < 2){
			cout << "0\n";
			continue;
		}
		long long count = 0;
		for(auto &[start, end]: ranges){
			if(start > N){
				continue;
			}
			int actual_end = min(end, N);
			if(actual_end >= start){
				count += (long long)(actual_end - start + 1);
			}
		}
		cout << count << "\n";
	}
}

