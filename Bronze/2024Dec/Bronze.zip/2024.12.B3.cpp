#include <bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	
	int N,F;
	cin >> N >> F;
	
	string S;
	S.reserve(N);
	cin >> S;
	
	const int TOTAL = 26*26*26;
	vector<int> countM(TOTAL, 0);
	vector<int> enc(N-2);
	
	for(int i=0; i<N-2; i++){
		int a = S[i]   - 'a';
		int b = S[i+1] - 'a';
		int c = S[i+2] - 'a';
		int id = a*676 + b*26 + c;
		enc[i] = id;
		if(a != b && b == c){
			countM[id]++;
		}
	}
	
	vector<int> mook = countM;
	vector<int> used(TOTAL, 0);
	for(int i=0; i<TOTAL; i++){
		if(mook[i] >= F) used[i] = 1;
	}
	
	for(int i=0; i<N; i++){
		char orig = S[i];
		vector<int> subs; 
		if(i-2 >= 0)     subs.push_back(i-2);
		if(i-1 >= 0 && i+1 < N) subs.push_back(i-1);
		if(i   >= 0 && i+2 < N) subs.push_back(i);
		
		vector<int> oldID(subs.size()), oldIsMoo(subs.size()), oldCount(subs.size());
		for(int k=0; k<(int)subs.size(); k++){
			int idx = subs[k];
			oldID[k] = enc[idx];
			int A = oldID[k] / 676;
			int r = oldID[k] % 676;
			int B = r / 26;
			int C = r % 26;
			oldIsMoo[k] = (A != B && B == C);
			oldCount[k] = mook[oldID[k]];
		}
		
		for(int j=0; j<26; j++){
			char ch = 'a' + j;
			if(ch == orig) continue;
			S[i] = ch;
			vector<int> newID(subs.size());
			vector<int> newIsMoo(subs.size(), 0);
			for(int k=0; k<(int)subs.size(); k++){
				int idx = subs[k];
				int A = S[idx]   - 'a';
				int B = S[idx+1] - 'a';
				int C = S[idx+2] - 'a';
				newID[k] = A*676 + B*26 + C;
				newIsMoo[k] = (A != B && B == C);
			}
			
			for(int k=0; k<(int)subs.size(); k++){
				if(oldIsMoo[k]) mook[oldID[k]]--;
				if(newIsMoo[k]) mook[newID[k]]++;
			}
			
			for(int k=0; k<(int)subs.size(); k++){
				if(newIsMoo[k] && mook[newID[k]] >= F && !used[newID[k]]) {
					used[newID[k]] = 1;
				}
			}
			
			for(int k=0; k<(int)subs.size(); k++){
				if(oldIsMoo[k]) mook[oldID[k]]++;
				if(newIsMoo[k]) mook[newID[k]]--;
			}
		}
		S[i] = orig;
	}
	
	vector<string> moos;
	moos.reserve(TOTAL);
	for(int i=0; i<TOTAL; i++){
		if(!used[i]) continue;
		int A = i / 676;
		int r = i % 676;
		int B = r / 26;
		int C = r % 26;
		if(A != B && B == C){
			string s3;
			s3.push_back((char)('a' + A));
			s3.push_back((char)('a' + B));
			s3.push_back((char)('a' + C));
			moos.push_back(s3);
		}
	}
	
	sort(moos.begin(), moos.end());
	moos.erase(unique(moos.begin(), moos.end()), moos.end());
	
	cout << moos.size() << "\n";
	for(auto &m : moos){
		cout << m << "\n";
	}
	
	return 0;
}

